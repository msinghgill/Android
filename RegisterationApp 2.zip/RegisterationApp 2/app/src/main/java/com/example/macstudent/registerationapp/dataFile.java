package com.example.macstudent.registerationapp;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class dataFile {
    ArrayList<String> usernameAL = new ArrayList<String>();
    ArrayList<String> passwordAL = new ArrayList<String>();
    ArrayList<String> firstNameAL = new ArrayList<String>();
    ArrayList<String> lastNameAL = new ArrayList<String>();
    ArrayList<String> emailAL = new ArrayList<String>();




}
