package com.example.macstudent.registerationapp;

import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;

    EditText userName, password, firstName, lastName, email;
    TextView firstNameText, lastNameText, emailText;
    Button button;
    Switch aSwitch;
    dataFile datafile = new dataFile();
    int index = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userName = findViewById(R.id.username);
        firstName = findViewById(R.id.firstName);
        password = findViewById(R.id.password);
        lastName = findViewById(R.id.lastname);
        email = findViewById(R.id.email);
        button = findViewById(R.id.button);
        aSwitch = findViewById(R.id.switch1);
        firstNameText = findViewById(R.id.firstnameText);
        lastNameText = findViewById(R.id.lastnameText);
        emailText = findViewById(R.id.emailText);


        userName.setText("");password.setText("");
        firstName.setText("");lastName.setText("");
        email.setText("");
        firstNameText.setVisibility(View.GONE);
        firstName.setVisibility(View.GONE);
        lastNameText.setVisibility(View.GONE);
        lastName.setVisibility(View.GONE);
        emailText.setVisibility(View.GONE);
        email.setVisibility(View.GONE);
        button.setText("SIGN IN");



        mediaPlayer = MediaPlayer.create(this,R.raw.airplane);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (button.getText().toString().equals("SIGN IN"))
                {
                    signIn(v);
                }
                else if(button.getText().toString().equals("Ok"))
                {
                    Toast.makeText(MainActivity.this, "All Information Is Correct", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    alerting(v);

                }


            }
        });






    }

    @Override
    protected void onStart() {
        super.onStart();

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked)
                {
                    userName.setText("");password.setText("");
                    firstName.setText("");lastName.setText("");
                    email.setText("");
                    firstNameText.setVisibility(View.GONE);
                    firstName.setVisibility(View.GONE);
                    lastNameText.setVisibility(View.GONE);
                    lastName.setVisibility(View.GONE);
                    emailText.setVisibility(View.GONE);
                    email.setVisibility(View.GONE);
                    button.setText("SIGN IN");
                }
                else
                {

                    firstName.setText("");lastName.setText("");
                    email.setText("");
                    userName.setText("");password.setText("");
                    firstNameText.setVisibility(View.VISIBLE);
                    firstName.setVisibility(View.VISIBLE);
                    lastNameText.setVisibility(View.VISIBLE);
                    lastName.setVisibility(View.VISIBLE);
                    emailText.setVisibility(View.VISIBLE);
                    email.setVisibility(View.VISIBLE);
                    button.setText("Register");
                }
            }
        });


    }
    public void register()
    {
        try {
            if (userName.getText().toString().trim().length() <= 0) {
                Toast.makeText(MainActivity.this, "Username is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.getText().toString().trim().length() <= 0) {
                Toast.makeText(MainActivity.this, "Password is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (firstName.getText().toString().trim().length() <= 0) {
                Toast.makeText(MainActivity.this, "First Name is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (lastName.getText().toString().trim().length() <= 0) {
                Toast.makeText(MainActivity.this, "Last Name is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (email.getText().toString().trim().length() <= 0) {
                Toast.makeText(MainActivity.this, "Email is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!userName.getText().toString().equals("") && !password.getText().toString().equals("") && !firstName.getText().toString().equals("") && !lastName.getText().toString().equals("") && !email.getText().toString().equals("")) {

                   if (datafile.usernameAL.contains(userName.getText().toString()))
                   {
                       Toast.makeText(this, "Username Already Taken", Toast.LENGTH_SHORT).show();
                       firstName.setText("");lastName.setText("");
                       email.setText("");
                       userName.setText("");password.setText("");
                   }
                else {

                       datafile.usernameAL.add(userName.getText().toString());
                       datafile.passwordAL.add(password.getText().toString());
                       datafile.firstNameAL.add(firstName.getText().toString());
                       datafile.lastNameAL.add(lastName.getText().toString());
                       datafile.emailAL.add(email.getText().toString());
                       firstName.setText("");lastName.setText("");
                       email.setText("");
                       userName.setText("");password.setText("");


                       mediaPlayer.start();


                       Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();
                   }

            }
            else
            {
                Toast.makeText(MainActivity.this, "PLease Fill all the Fields", Toast.LENGTH_SHORT).show();
            }
        }
        catch(Exception e) {
            e.printStackTrace(System.out);
        }



    }


    public void signIn(View view)
    {
        if (!userName.getText().toString().equals("") && !password.getText().toString().equals(""))
        {
            if (datafile.usernameAL.contains(userName.getText().toString()) && datafile.passwordAL.contains(password.getText().toString()))
            {
                index = datafile.usernameAL.indexOf(userName.getText().toString());
                Toast.makeText(this, "Login SuccessFull", Toast.LENGTH_SHORT).show();

                firstNameText.setVisibility(View.VISIBLE);
                firstName.setVisibility(View.VISIBLE);
                lastNameText.setVisibility(View.VISIBLE);
                lastName.setVisibility(View.VISIBLE);
                emailText.setVisibility(View.VISIBLE);
                email.setVisibility(View.VISIBLE);

                firstName.setText(datafile.firstNameAL.get(index));
                lastName.setText(datafile.lastNameAL.get(index));
                email.setText(datafile.emailAL.get(index));
                button.setText("Ok");



            }
            else
            {
                userName.setText("");password.setText("");
                Toast.makeText(this, "Wrong Combination Entered", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(this, "Username and Password Fields Are Empty", Toast.LENGTH_SHORT).show();
        }
    }
     public void alerting(final View view)
     {
         AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
         builder1.setMessage("Are you sure?");
         builder1.setCancelable(true);

         builder1.setPositiveButton(
                 "Yes, I am sure!",
                 new DialogInterface.OnClickListener() {
                     public void onClick(DialogInterface dialog, int id) {
                         //dialog.cancel();
                         register();
                     }
                 });

         builder1.setNegativeButton(
                 "No!",
                 new DialogInterface.OnClickListener() {
                     public void onClick(DialogInterface dialog, int id) {
                         dialog.cancel();
                     }
                 });

         AlertDialog alert11 = builder1.create();
         alert11.show();
     }
}



















